// components/Background.tsx
import React from "react";
import "./css/Background.css";

const Background: React.FC = () => {
  return (
    <div>
        <h1 className="background-container">TESTE TESTE TESTE</h1>
    </div>
  );
};

export default Background;