import React from "react";

const Videos: React.FC = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>🎥 Family Videos</h1>
      <p>This is where you’ll see the video gallery.</p>
    </div>
  );
};

export default Videos;
