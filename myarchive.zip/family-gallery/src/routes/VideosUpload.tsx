import React from "react";

const VideosUpload: React.FC = () => {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>📷 Upload Photos</h1>
      <p>Select and upload videos to the cloud.</p>
    </div>
  );
};

export default VideosUpload;