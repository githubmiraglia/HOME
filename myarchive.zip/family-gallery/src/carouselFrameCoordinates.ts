export const carouselFrameCoordinates = {
  frame_1:   { left: "6.2%",  top: "13.%",  width: "9.9%", height: "17.2%" },
  frame_2:   { left: "23.4%", top: "13.%",  width: "12.6%", height: "17.2%" },
  frame_3:   { left: "43.7%", top: "13.%",  width: "10.9%", height: "17.6%" },
  frame_4:   { left: "62.5%", top: "15.7%",  width: "10.6%", height: "11.5%" },
  frame_5:   { left: "80.6%", top: "13.%",  width: "11.6%", height: "17.6%" },

  frame_6:   { left: "5.95%",  top: "41.8%", width: "12.65%", height: "15.9%" },
  frame_7:   { left: "27.48%", top: "43.%", width: "9%", height: "14.%" },
  frame_8:   { left: "44.1%", top: "43.%", width: "10.5%", height: "12.2%" },
  frame_9:   { left: "62.4%", top: "40.2%", width: "11.6%", height: "17.9%" },
  frame_10:  { left: "81.8%", top: "43.7%", width: "9.9%", height: "11.8%" },

  frame_11:  { left: "6.1%", top: "69.4%", width: "9.9%", height: "14.8%" },
  frame_12:  { left: "23.7%", top: "68.6%", width: "12.8%", height: "15.9%" },
  frame_13:  { left: "44.3%", top: "69.8%", width: "9%", height: "14.%" },
  frame_14:  { left: "60.95%", top: "69.8%", width: "11%", height: "15.8%" },
  frame_15:  { left: "79.3%", top: "69.4%", width: "12.9%", height: "14.8%" }
};
